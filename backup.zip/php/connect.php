<?php
$db_host = "localhost";
$db_user = "metalx_jenn";
$db_pass = "EwhM{(^0[43Z";
$db_name = "metalx_ticket";

@mysql_connect("$db_host","$db_user","$db_pass") or die ("Could Not Connect");
@mysql_select_db("$db_name") or die ("Could not find DB");


?> 
